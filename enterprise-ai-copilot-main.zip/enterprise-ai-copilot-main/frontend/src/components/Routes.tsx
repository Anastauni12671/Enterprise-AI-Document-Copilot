import { Navigate, Outlet } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';

export function ProtectedRoute() {
    const token = useAuthStore((state) => state.token);

    if (!token) {
        return <Navigate to="/login" replace />;
    }

    return <Outlet />;
}

export function PublicRoute() {
    const token = useAuthStore((state) => state.token);

    if (token) {
        return <Navigate to="/chat" replace />;
    }

    return <Outlet />;
}
